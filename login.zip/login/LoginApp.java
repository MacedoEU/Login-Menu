

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import main.player.PlayerMain;

public class LoginApp {

	static List<Login> addAccount = new ArrayList<>();
	
public static void main(String[] args) {
	loginStart(); 	
}
	
public static void loginStart() {
	readAccounts();
	userInputUsernamePassword(); 
}

private static void userInputUsernamePassword() {
	
	String username; 
	String password;
	Scanner sc = new Scanner(System.in);
	System.out.println("	 Login!!!");
	System.out.println("---------------------------------------"); 
	System.out.print("Please enter in your username: ");
	username = sc.nextLine(); 
	System.out.print("Please enter in your password: "); 
	password = sc.nextLine(); 
	System.out.println("----------------------------------------"); 
	System.out.println(""); 
	dataReview(username, password);
	sc.close();
	
}

private static void dataReview(String username, String password) {
	
	System.out.println("Data Entered"); 
	System.out.println("---------------------------------------"); 
	System.out.println("Username: " + username); 
	System.out.println("Password: " + password);
	System.out.println("---------------------------------------"); 
	System.out.println("Are you happy with the data entered? (Y for Yes), (N for No)"); 
	dataReviewDescion(username, password);
}

private static void dataReviewDescion(String username, String password) {
	Scanner sc = new Scanner(System.in);
	System.out.print("Input: ");
	char input = sc.next().charAt(0);
	
	
	if (input == 'y' || input  == 'Y') {
		username.toLowerCase(); 
		password.toLowerCase();
		System.out.println(""); 
		loginDescion(username, password);
	}
	
	else if (input == 'n' || input == 'N') {
		System.out.println(""); 
		userInputUsernamePassword(); 
	}
	
	else {
		System.out.println("");
		System.out.println("-------------------------------------------------------------------------------------------------"); 
		System.out.println("Incorrect data has been entered " + input + " please enter in [y] for yes and [n] for no");
		System.out.println("-------------------------------------------------------------------------------------------------"); 
		dataReviewDescion(username, password);
	}
	
	sc.close();
	

}

private static void loginDescion(String username, String password) {

	if (searchAccount(username, password)  ==true) {
		System.out.println(""); 
		System.out.println("-----------------------------------");
		System.out.println("Login is succesful: "); 
		System.out.println("-----------------------------------");
		System.out.println(""); 
	}
	
	
	else if (searchAccount(username, password)  == false) {
		System.out.println(""); 
		System.out.println("------------------------------------------------------------------------------------------------------------------------"); 
		System.out.println("Login is unsuccesful: No account has been found with the username of " + username + " and/or password of " + password); 
		System.out.println("------------------------------------------------------------------------------------------------------------------------"); 
		System.out.println(""); 
		userInputUsernamePassword();
	}
}

private static void readAccounts() {
	
	 try (BufferedReader br = new BufferedReader(new FileReader("Account.csv")))
     {
         String line;
         while((line = br.readLine()) != null)
         {
             String[] values = line.split(",");
             
             Login login = new Login();
             
             login.setUsername(values[0]);  
             login.setPassword(values[1]);
         
             addAccount.add(login);
             
         }
     }
     catch (FileNotFoundException e)
     {
         e.printStackTrace();
     } 
     catch (IOException e)
     {
         e.printStackTrace();
     }
     // Print an empty line to divide each file
     System.out.println("");
 }


private static boolean searchAccount(String username, String password) {
	
	for (int index = 0; index < addAccount.size(); index++ ) {
		Login loginC = addAccount.get(index); 
		String thisUsername = loginC.getUsername(); 
		String thisPassword = loginC.getPassword(); 
		
			if (thisUsername.equals(username) && thisPassword.equals(password)) {
				return true;
			}
	}
	return false;
}




	
}

